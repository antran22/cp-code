#pragma once

#include <string>

std::string guess(int n, int t);

// Library method:

bool make_test(std::string p);

