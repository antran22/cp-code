#! /bin/bash

g++ -O2 -std=c++11 -static -o B sample_grader.cpp B.cpp
