#include "grader.h"

#include <cstdlib>

std::string guess(int n, int t) {
    make_test("0");
    return "0";
}